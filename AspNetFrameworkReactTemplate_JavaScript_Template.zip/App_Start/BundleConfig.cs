﻿using System.Web;


namespace $safeprojectname$
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
       
    }
}
