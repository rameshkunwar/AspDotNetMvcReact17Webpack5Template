{
    "compilerOptions":{
        "target":"es6"
    }
}